package com.entity.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.layer1.Payeedetail;
import com.entity.layer2.PayeedetailRepository;
import com.entity.layer2.UserdetailRepository;
import com.entity.layer3.PayeedetailDTO;
import com.entity.layer3.viewPayeedetail;


@Service
public class PayeedetailServiceImpl implements PayeedetailService {
	
	@Autowired
	PayeedetailRepository repo;
	@Autowired
	UserdetailRepository userRepo;
	

	public List<viewPayeedetail> getPayeeNameAndAccNo(String fromAcc) {
		 return  repo.getPayeedetail(fromAcc);
	}


	@Override
	public void addPayeedetail(PayeedetailDTO payee) throws Exception {
	
	//	System.out.println(payee.getPaccno());
 
		//System.out.println(payee.getPayeeAcNumber());
		//System.out.println(payee.getUserAcNumber());
	//	System.out.println(userRepo.isAccountActive(payee.getPaccno()));
	//	System.out.println("payee3");
		
			if(!userRepo.isAccountActive(payee.getPaccno())) 
				
			{
				throw new Exception("Payee account does not exist");
			}
	
				if(userRepo.isAccountPresent(payee.getUaccno(), payee.getPaccno()))
				{
					
					throw new Exception("Payee account already exist");
				} 
				
				
					
					if((payee.getPaccno()).equals(payee.getUaccno())) 
					{
						
						
						throw new Exception("Payee account yourself exist");
					} 
					else
					{
						
						Payeedetail payeedetails = new Payeedetail();
						
					//payeedetails.setPayeeid(payeeid);
						payeedetails.setPayeeaccountnumber(payee.getPaccno());
						payeedetails.setPayeename(payee.getPname());
						payeedetails.setUseraccountnumber(payee.getUaccno());
					//	System.out.println("hello4");
					//	System.out.println(payeedetails);
						repo.save(payeedetails);
					}
				
			
		
	}
}